clear;
clc;
warning off;
addpath(genpath('./'));

%% dataset
ds = {'FashionMV.mat'};
metric = {'ACC','nmi','Purity','Fscore','Precision','Recall','AR','Entropy'};

for dsi = 1:length(ds)
    %% load data & make folder
    dataName = ds{dsi};
    load(dataName);

    % n*d则需要转置
    for iv = 1 : length(X)
        X{iv} = X{iv}';
    end

    k = length(unique(Y));
    n = length(Y);
%     matpath = strcat(resPath,dataName);
%     txtpath = strcat(resPath,strcat(dataName,'.txt'));
%     if (~exist(matpath,'file'))
%         mkdir(matpath);
%         addpath(genpath(matpath));
%     end
    %% initialize A
    for iv = 1:length(X)
        if size(X{iv},2)~= n
            X{iv} = X{iv}';
        end
        X{iv} = NormalizeFea(X{iv}, 0);
    end
    %% param setting
    MM = [1 3 5];
    AP = [1e-3, 1e-2, 1e-1, 1e0, 1e1, 1e2, 1e3];
%     BT = [1e-3, 1e-2, 1e-1, 1e0, 1e1, 1e2, 1e3];
    PP = [0.1,0.3,0.5,0.7,0.9,1];
%     MM = [3]; 
%     AP = [10];
    BT = [0];
    Result  = [];
    folder_name = 'convergence';
    %% 
    perf = []; perf_svd=[];
    iter_pp = 1;
    for rp0 = 1:length(MM)
        m = MM(rp0);
        for rp1 = 1:length(AP)
            for rp2 = 1:length(BT)
                for rp3 = 1:length(PP)
                 param.alpha = AP(rp1);
                 param.beta = BT(rp2);
                 param.p =  PP(rp3);
                tic
                [U,A, Z, obj] = camvc(X, n, k, m, param);
    %             [U, A, Z, obj] = Copy_of_camvc(X, n, k, m, param);
            
                [res] = myNMIACCwithmean(U,Y,k); %[ACC nmi Purity Fscore Precision Recall AR Entropy];
                res_std = std(res);
                time_cost  = toc;
                Result = [Result;AP(rp1), BT(rp2),MM(rp0),PP(rp3),res,res_std,time_cost];
                fprintf("\n ITER: (%d, %d, %d) ACC, NMI, Purity, F: %.4f, %.4f, %.4f, %.4f, %.4f, %.4f \n", rp0, rp1, rp2, res(1), res(2),res(3),res(4));
                end 
            end
        end
    end
end

function [U,A, Z, obj] = camvc(X, n, k, m, param)
% 


mu = 1e-4;
mu_max = 1e6;
rho = 1.2;
p = param.p;
num_view = length(X);
weight_vector = ones(1, num_view)';
num_sample = size(X{1},2);
for i = 1:num_view
    A{i} = zeros(size(X{i},1), m*k);
    G{i} = zeros(m*k, size(X{i},2));
    C{i} = zeros(m*k, size(X{i},2));
end
alpha = param.alpha;
beta  = param.beta;

if size(X{1},2)~=n
    for iv = 1:num_view
        X{iv} = X{iv}';
    end
end
for iv = 1:num_view
    X{iv} = NormalizeFea(X{iv},0);
end
clear iv

% initialization
I = eye(k); Y= [];
for ik = 1:k
    Y = [Y repmat(I(:,ik),1,m)];
end
clear I


for iv = 1:num_view
    [Up,~,Sp] = svd(A{iv}*Y', 'econ');
    P{iv} = Up*Sp';
end
clear Up Sp


w = ones(1, num_view);%/num_view;


MAX_ITER = 50;

for iter = 1:MAX_ITER
  
    %% Z{iv} step
    for iv = 1 : num_view
        Z{iv} = (+ 2*A{iv}'*A{iv}  + mu* eye(m*k))\(2*A{iv}'*X{iv} + mu*G{iv}-C{iv});
    end
%     tZ1 = 0; tZ2=  0;
%     for iv = 1:num_view
%         tZ1 = tZ1 + w(iv)^2*A{iv}'*A{iv};
%         tZ2 = tZ2 + w(iv)^2*A{iv}'*X{iv};
%     end
%      Z = (tZ1 + beta*eye(m*k))\tZ2;

    %% A step
    for iv = 1:num_view
        A{iv} = (X{iv}*Z{iv}' + alpha*P{iv}*Y)/(Z{iv}*Z{iv}' + alpha*eye(m*k));
    end
 
    % P step
     for iv = 1:num_view
        [Up,~,Sp] = svd(A{iv}*Y', 'econ');
        P{iv} = Up*Sp';
     end
     clear Up Sp

   %% G step
   Z_tensor  = cat(3, Z{:,:});
   C_tensor = cat(3, C{:,:});
   z = Z_tensor(:);
   c = C_tensor(:);
%    [g, objV] = wshrinkObj(z + 1/mu * c,beta/mu,[m*k, num_sample,  num_view],0,1);
   [g, objV] = wshrinkObj_weight_lp(z + 1/mu * c, beta * (weight_vector)./ mu, [m*k, num_sample,  num_view], 0, 1, p);
   G_tensor = reshape(g, [m*k, num_sample,  num_view]);
   objV;
    C_tensor = C_tensor + mu * (Z_tensor - G_tensor);

    for iv = 1 : num_view
        Z{iv} = Z_tensor(:,:,iv);
        G{iv} = G_tensor(:,:,iv);
        C{iv} = C_tensor(:,:,iv); 
    end
    mu = min(mu * rho, mu_max);
    
    obj(iter) = calobj(X, A, Z, P, Y, w, num_view, alpha, beta,objV);
    if (iter>2) && ( abs((obj(iter-1)-obj(iter))/(obj(iter-1)))<1e-4|| iter>MAX_ITER)
        break
    end

end
U = zeros(m*k,num_sample);
for iv = 1 : num_view
        U = U + 1/num_view*Z{iv};
end
U = U';

end

function obj = calobj(X, A, Z, P, Y, w, num_view, alpha, beta,objV)
obj = 0;
for iv = 1:num_view
    err = X{iv}-A{iv}*Z{iv};
    err2 = A{iv} - P{iv}*Y;
    obj = obj + w(iv)^2*(sum(sum(err.*err)) + alpha*sum(sum(err2.*err2)));
end

obj = obj +  beta*objV;

end
